# Amazon-like E-Commerce Web Application

This is a full-featured e-commerce web application that replicates the core functionality of Amazon, built with a FastAPI backend and a modern React frontend.

## Features

- User registration, login, and authentication (JWT)
- Advanced product search with filtering and sorting
- Product pages with images, descriptions, reviews, and ratings
- Shopping cart, checkout, and payment integration
- Order management and tracking
- Wishlist and save-for-later functionality
- Admin panel for product/user/order management
- Responsive design for desktop and mobile devices

## Tech Stack

### Backend
- FastAPI (Python)
- PostgreSQL
- SQLAlchemy ORM
- JWT Authentication

### Frontend
- React
- Material UI
- React Router
- React Query
- Axios

## Project Structure

```
ecommerce-app/
├── backend/
│   ├── app/
│   │   ├── api/
│   │   ├── core/
│   │   ├── crud/
│   │   ├── db/
│   │   ├── models/
│   │   ├── routes/
│   │   ├── schemas/
│   │   ├── utils/
│   │   └── main.py
│   ├── Dockerfile
│   └── requirements.txt
├── frontend/
│   ├── public/
│   ├── src/
│   │   ├── assets/
│   │   ├── components/
│   │   ├── context/
│   │   ├── pages/
│   │   ├── services/
│   │   ├── App.js
│   │   └── index.js
│   ├── Dockerfile
│   └── package.json
└── docker-compose.yml
```

## Getting Started

### Prerequisites

- Docker and Docker Compose

### Installation and Setup

1. Clone the repository
2. Navigate to the project directory
3. Run the application using Docker Compose:

```bash
docker-compose up -d
```

4. Access the application:
   - Frontend: http://localhost:3000
   - Backend API: http://localhost:8000/docs

## API Documentation

The API documentation is available at http://localhost:8000/docs when the application is running.

## Development

### Backend Development

To run the backend separately:

```bash
cd backend
pip install -r requirements.txt
uvicorn app.main:app --reload
```

### Frontend Development

To run the frontend separately:

```bash
cd frontend
npm install
npm start
```

## Deployment

The application is containerized using Docker and can be deployed to any environment that supports Docker containers.

## License

This project is licensed under the MIT License.
