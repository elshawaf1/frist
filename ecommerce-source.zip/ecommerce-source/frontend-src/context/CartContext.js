import React, { createContext, useContext, useState, useEffect } from 'react';
import { cartService } from '../services/api';

// Create the cart context
const CartContext = createContext(null);

// Custom hook to use the cart context
export const useCart = () => useContext(CartContext);

// Provider component that wraps the app and makes cart object available to any child component that calls useCart()
export const CartProvider = ({ children }) => {
  const [cartItems, setCartItems] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [cartTotal, setCartTotal] = useState(0);
  const [itemCount, setItemCount] = useState(0);

  // Fetch cart on initial load and when auth state changes
  const fetchCart = async () => {
    setLoading(true);
    setError(null);
    try {
      const token = localStorage.getItem('token');
      if (token) {
        const response = await cartService.getCart();
        setCartItems(response.data.items || []);
        calculateTotals(response.data.items || []);
      } else {
        // Handle guest cart from localStorage
        const guestCart = JSON.parse(localStorage.getItem('guestCart')) || [];
        setCartItems(guestCart);
        calculateTotals(guestCart);
      }
    } catch (err) {
      setError(err.response?.data?.detail || 'Failed to fetch cart');
      console.error('Failed to fetch cart:', err);
    } finally {
      setLoading(false);
    }
  };

  // Calculate cart totals
  const calculateTotals = (items) => {
    const total = items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const count = items.reduce((sum, item) => sum + item.quantity, 0);
    setCartTotal(total);
    setItemCount(count);
  };

  // Add item to cart
  const addToCart = async (product, quantity = 1) => {
    setLoading(true);
    setError(null);
    try {
      const token = localStorage.getItem('token');
      if (token) {
        // Authenticated user - use API
        await cartService.addToCart(product.id, quantity);
        await fetchCart(); // Refresh cart after adding
      } else {
        // Guest user - use localStorage
        const guestCart = JSON.parse(localStorage.getItem('guestCart')) || [];
        const existingItemIndex = guestCart.findIndex(item => item.product_id === product.id);
        
        if (existingItemIndex >= 0) {
          // Update quantity if item exists
          guestCart[existingItemIndex].quantity += quantity;
        } else {
          // Add new item
          guestCart.push({
            id: Date.now(), // Temporary ID
            product_id: product.id,
            product: product,
            quantity: quantity,
            price: product.price
          });
        }
        
        localStorage.setItem('guestCart', JSON.stringify(guestCart));
        setCartItems(guestCart);
        calculateTotals(guestCart);
      }
      return true;
    } catch (err) {
      setError(err.response?.data?.detail || 'Failed to add item to cart');
      console.error('Failed to add item to cart:', err);
      return false;
    } finally {
      setLoading(false);
    }
  };

  // Update cart item quantity
  const updateCartItem = async (itemId, quantity) => {
    setLoading(true);
    setError(null);
    try {
      const token = localStorage.getItem('token');
      if (token) {
        // Authenticated user - use API
        await cartService.updateCartItem(itemId, quantity);
        await fetchCart(); // Refresh cart after updating
      } else {
        // Guest user - use localStorage
        const guestCart = JSON.parse(localStorage.getItem('guestCart')) || [];
        const updatedCart = guestCart.map(item => 
          item.id === itemId ? { ...item, quantity } : item
        );
        
        localStorage.setItem('guestCart', JSON.stringify(updatedCart));
        setCartItems(updatedCart);
        calculateTotals(updatedCart);
      }
      return true;
    } catch (err) {
      setError(err.response?.data?.detail || 'Failed to update cart');
      console.error('Failed to update cart:', err);
      return false;
    } finally {
      setLoading(false);
    }
  };

  // Remove item from cart
  const removeFromCart = async (itemId) => {
    setLoading(true);
    setError(null);
    try {
      const token = localStorage.getItem('token');
      if (token) {
        // Authenticated user - use API
        await cartService.removeFromCart(itemId);
        await fetchCart(); // Refresh cart after removing
      } else {
        // Guest user - use localStorage
        const guestCart = JSON.parse(localStorage.getItem('guestCart')) || [];
        const updatedCart = guestCart.filter(item => item.id !== itemId);
        
        localStorage.setItem('guestCart', JSON.stringify(updatedCart));
        setCartItems(updatedCart);
        calculateTotals(updatedCart);
      }
      return true;
    } catch (err) {
      setError(err.response?.data?.detail || 'Failed to remove item from cart');
      console.error('Failed to remove item from cart:', err);
      return false;
    } finally {
      setLoading(false);
    }
  };

  // Clear cart
  const clearCart = async () => {
    setLoading(true);
    setError(null);
    try {
      const token = localStorage.getItem('token');
      if (token) {
        // Authenticated user - use API
        await cartService.clearCart();
      }
      // Always clear local state and localStorage
      localStorage.removeItem('guestCart');
      setCartItems([]);
      setCartTotal(0);
      setItemCount(0);
      return true;
    } catch (err) {
      setError(err.response?.data?.detail || 'Failed to clear cart');
      console.error('Failed to clear cart:', err);
      return false;
    } finally {
      setLoading(false);
    }
  };

  // Fetch cart on initial load
  useEffect(() => {
    fetchCart();
  }, []);

  // Context value
  const value = {
    cartItems,
    loading,
    error,
    cartTotal,
    itemCount,
    addToCart,
    updateCartItem,
    removeFromCart,
    clearCart,
    refreshCart: fetchCart
  };

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
};
