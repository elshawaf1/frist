import React, { createContext, useContext, useState, useEffect } from 'react';
import { wishlistService } from '../services/api';

// Create the wishlist context
const WishlistContext = createContext(null);

// Custom hook to use the wishlist context
export const useWishlist = () => useContext(WishlistContext);

// Provider component that wraps the app and makes wishlist object available to any child component that calls useWishlist()
export const WishlistProvider = ({ children }) => {
  const [wishlistItems, setWishlistItems] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // Fetch wishlist on initial load and when auth state changes
  const fetchWishlist = async () => {
    setLoading(true);
    setError(null);
    try {
      const token = localStorage.getItem('token');
      if (token) {
        const response = await wishlistService.getWishlist();
        setWishlistItems(response.data.items || []);
      } else {
        // Handle guest wishlist from localStorage
        const guestWishlist = JSON.parse(localStorage.getItem('guestWishlist')) || [];
        setWishlistItems(guestWishlist);
      }
    } catch (err) {
      setError(err.response?.data?.detail || 'Failed to fetch wishlist');
      console.error('Failed to fetch wishlist:', err);
    } finally {
      setLoading(false);
    }
  };

  // Add item to wishlist
  const addToWishlist = async (product) => {
    setLoading(true);
    setError(null);
    try {
      const token = localStorage.getItem('token');
      if (token) {
        // Authenticated user - use API
        await wishlistService.addToWishlist(product.id);
        await fetchWishlist(); // Refresh wishlist after adding
      } else {
        // Guest user - use localStorage
        const guestWishlist = JSON.parse(localStorage.getItem('guestWishlist')) || [];
        const existingItem = guestWishlist.find(item => item.product_id === product.id);
        
        if (!existingItem) {
          // Add new item
          guestWishlist.push({
            id: Date.now(), // Temporary ID
            product_id: product.id,
            product: product
          });
          
          localStorage.setItem('guestWishlist', JSON.stringify(guestWishlist));
          setWishlistItems(guestWishlist);
        }
      }
      return true;
    } catch (err) {
      setError(err.response?.data?.detail || 'Failed to add item to wishlist');
      console.error('Failed to add item to wishlist:', err);
      return false;
    } finally {
      setLoading(false);
    }
  };

  // Remove item from wishlist
  const removeFromWishlist = async (itemId) => {
    setLoading(true);
    setError(null);
    try {
      const token = localStorage.getItem('token');
      if (token) {
        // Authenticated user - use API
        await wishlistService.removeFromWishlist(itemId);
        await fetchWishlist(); // Refresh wishlist after removing
      } else {
        // Guest user - use localStorage
        const guestWishlist = JSON.parse(localStorage.getItem('guestWishlist')) || [];
        const updatedWishlist = guestWishlist.filter(item => item.id !== itemId);
        
        localStorage.setItem('guestWishlist', JSON.stringify(updatedWishlist));
        setWishlistItems(updatedWishlist);
      }
      return true;
    } catch (err) {
      setError(err.response?.data?.detail || 'Failed to remove item from wishlist');
      console.error('Failed to remove item from wishlist:', err);
      return false;
    } finally {
      setLoading(false);
    }
  };

  // Check if product is in wishlist
  const isInWishlist = (productId) => {
    return wishlistItems.some(item => item.product_id === productId);
  };

  // Fetch wishlist on initial load
  useEffect(() => {
    fetchWishlist();
  }, []);

  // Context value
  const value = {
    wishlistItems,
    loading,
    error,
    addToWishlist,
    removeFromWishlist,
    isInWishlist,
    refreshWishlist: fetchWishlist
  };

  return <WishlistContext.Provider value={value}>{children}</WishlistContext.Provider>;
};
