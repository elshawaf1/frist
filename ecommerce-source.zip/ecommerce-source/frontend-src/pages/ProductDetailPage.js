import React, { useState, useEffect } from 'react';
import { 
  Box, 
  Container, 
  Typography, 
  Grid, 
  Card, 
  CardMedia, 
  CardContent, 
  Button, 
  Divider,
  Rating,
  Tabs,
  Tab,
  TextField,
  Avatar,
  Breadcrumbs,
  Link,
  Chip,
  IconButton
} from '@mui/material';
import { Link as RouterLink, useParams } from 'react-router-dom';
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import FavoriteIcon from '@mui/icons-material/Favorite';
import ShareIcon from '@mui/icons-material/Share';
import NavigateNextIcon from '@mui/icons-material/NavigateNext';
import AddIcon from '@mui/icons-material/Add';
import RemoveIcon from '@mui/icons-material/Remove';

const ProductDetailPage = () => {
  const { id } = useParams();
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [quantity, setQuantity] = useState(1);
  const [activeTab, setActiveTab] = useState(0);
  const [relatedProducts, setRelatedProducts] = useState([]);

  // Dummy product data
  const dummyProduct = {
    id: parseInt(id),
    name: 'Wireless Noise Cancelling Headphones',
    price: 129.99,
    originalPrice: 159.99,
    rating: 4.5,
    reviewCount: 127,
    image: 'https://via.placeholder.com/600x600',
    images: [
      'https://via.placeholder.com/600x600',
      'https://via.placeholder.com/600x600',
      'https://via.placeholder.com/600x600',
      'https://via.placeholder.com/600x600'
    ],
    category: 'Electronics',
    brand: 'SoundMaster',
    description: 'Experience premium sound quality with these wireless noise cancelling headphones. Perfect for travel, work, or relaxation, these headphones deliver crystal-clear audio and exceptional comfort for all-day wear.',
    features: [
      'Active Noise Cancellation',
      'Bluetooth 5.0 Connectivity',
      'Up to 30 hours battery life',
      'Comfortable over-ear design',
      'Built-in microphone for calls',
      'Quick charge - 5 minutes for 3 hours playback'
    ],
    specifications: {
      'Connectivity': 'Bluetooth 5.0, 3.5mm audio cable',
      'Battery Life': 'Up to 30 hours',
      'Charging Time': '2 hours',
      'Weight': '250g',
      'Dimensions': '7.5 x 6.7 x 3.2 inches',
      'Color': 'Matte Black',
      'Warranty': '1 year manufacturer warranty'
    },
    stock: 15,
    reviews: [
      {
        id: 1,
        user: 'John D.',
        avatar: 'https://via.placeholder.com/40',
        rating: 5,
        date: '2025-03-15',
        comment: 'These headphones are amazing! The sound quality is exceptional and the noise cancellation works perfectly on my commute.'
      },
      {
        id: 2,
        user: 'Sarah M.',
        avatar: 'https://via.placeholder.com/40',
        rating: 4,
        date: '2025-03-10',
        comment: 'Very comfortable to wear for long periods. Battery life is impressive. The only downside is they\'re a bit bulky for travel.'
      },
      {
        id: 3,
        user: 'Michael T.',
        avatar: 'https://via.placeholder.com/40',
        rating: 5,
        date: '2025-02-28',
        comment: 'Best headphones I\'ve owned. The sound is balanced and clear, and they pair easily with all my devices.'
      }
    ]
  };

  // Dummy related products
  const dummyRelatedProducts = [
    {
      id: 101,
      name: 'Bluetooth Earbuds',
      price: 79.99,
      rating: 4.3,
      image: 'https://via.placeholder.com/300x300',
      category: 'Electronics'
    },
    {
      id: 102,
      name: 'Headphone Stand',
      price: 24.99,
      rating: 4.7,
      image: 'https://via.placeholder.com/300x300',
      category: 'Accessories'
    },
    {
      id: 103,
      name: 'Audio Adapter',
      price: 15.99,
      rating: 4.2,
      image: 'https://via.placeholder.com/300x300',
      category: 'Electronics'
    },
    {
      id: 104,
      name: 'Portable Speaker',
      price: 49.99,
      rating: 4.5,
      image: 'https://via.placeholder.com/300x300',
      category: 'Electronics'
    }
  ];

  // Load product data
  useEffect(() => {
    // Simulate API call
    setTimeout(() => {
      setProduct(dummyProduct);
      setRelatedProducts(dummyRelatedProducts);
      setLoading(false);
    }, 500);
  }, [id]);

  const handleTabChange = (event, newValue) => {
    setActiveTab(newValue);
  };

  const handleQuantityChange = (amount) => {
    const newQuantity = quantity + amount;
    if (newQuantity >= 1 && newQuantity <= product?.stock) {
      setQuantity(newQuantity);
    }
  };

  if (loading) {
    return (
      <Container>
        <Box sx={{ display: 'flex', justifyContent: 'center', my: 8 }}>
          <Typography>Loading product details...</Typography>
        </Box>
      </Container>
    );
  }

  if (!product) {
    return (
      <Container>
        <Box sx={{ display: 'flex', justifyContent: 'center', my: 8 }}>
          <Typography>Product not found</Typography>
        </Box>
      </Container>
    );
  }

  return (
    <Container className="fade-in">
      {/* Breadcrumbs */}
      <Breadcrumbs 
        separator={<NavigateNextIcon fontSize="small" />} 
        aria-label="breadcrumb"
        sx={{ my: 2 }}
      >
        <Link component={RouterLink} to="/" color="inherit">
          Home
        </Link>
        <Link component={RouterLink} to="/products" color="inherit">
          Products
        </Link>
        <Link component={RouterLink} to={`/products?category=${product.category}`} color="inherit">
          {product.category}
        </Link>
        <Typography color="text.primary">{product.name}</Typography>
      </Breadcrumbs>

      {/* Product Details */}
      <Grid container spacing={4} sx={{ mb: 6 }}>
        {/* Product Images */}
        <Grid item xs={12} md={6}>
          <Card elevation={0} sx={{ mb: 2 }}>
            <CardMedia
              component="img"
              image={product.image}
              alt={product.name}
              sx={{ height: 'auto', borderRadius: 2 }}
            />
          </Card>
          <Grid container spacing={1}>
            {product.images.map((img, index) => (
              <Grid item xs={3} key={index}>
                <Card 
                  sx={{ 
                    cursor: 'pointer',
                    border: index === 0 ? '2px solid' : '1px solid',
                    borderColor: index === 0 ? 'primary.main' : 'divider',
                    borderRadius: 2
                  }}
                >
                  <CardMedia
                    component="img"
                    image={img}
                    alt={`${product.name} view ${index + 1}`}
                    sx={{ height: 80 }}
                  />
                </Card>
              </Grid>
            ))}
          </Grid>
        </Grid>

        {/* Product Info */}
        <Grid item xs={12} md={6}>
          <Box>
            <Chip 
              label={product.category} 
              size="small" 
              sx={{ mb: 1 }} 
              color="primary" 
              variant="outlined" 
            />
            <Typography variant="h4" component="h1" gutterBottom>
              {product.name}
            </Typography>
            
            <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
              <Rating value={product.rating} precision={0.5} readOnly />
              <Typography variant="body2" sx={{ ml: 1 }}>
                ({product.reviewCount} reviews)
              </Typography>
            </Box>
            
            <Typography variant="body1" sx={{ mb: 3 }}>
              Brand: <strong>{product.brand}</strong>
            </Typography>
            
            <Box sx={{ display: 'flex', alignItems: 'baseline', mb: 3 }}>
              <Typography variant="h4" color="primary" sx={{ mr: 2 }}>
                ${product.price}
              </Typography>
              {product.originalPrice && (
                <Typography variant="body1" sx={{ textDecoration: 'line-through', color: 'text.secondary' }}>
                  ${product.originalPrice}
                </Typography>
              )}
              {product.originalPrice && (
                <Chip 
                  label={`Save $${(product.originalPrice - product.price).toFixed(2)}`} 
                  color="secondary" 
                  size="small" 
                  sx={{ ml: 2 }} 
                />
              )}
            </Box>
            
            <Typography variant="body1" sx={{ mb: 3 }}>
              {product.description}
            </Typography>
            
            <Divider sx={{ mb: 3 }} />
            
            {/* Quantity Selector */}
            <Box sx={{ display: 'flex', alignItems: 'center', mb: 3 }}>
              <Typography variant="body1" sx={{ mr: 2 }}>
                Quantity:
              </Typography>
              <Box sx={{ display: 'flex', alignItems: 'center', border: '1px solid', borderColor: 'divider', borderRadius: 1 }}>
                <IconButton size="small" onClick={() => handleQuantityChange(-1)} disabled={quantity <= 1}>
                  <RemoveIcon />
                </IconButton>
                <Typography sx={{ px: 2 }}>
                  {quantity}
                </Typography>
                <IconButton size="small" onClick={() => handleQuantityChange(1)} disabled={quantity >= product.stock}>
                  <AddIcon />
                </IconButton>
              </Box>
              <Typography variant="body2" color="text.secondary" sx={{ ml: 2 }}>
                {product.stock} available
              </Typography>
            </Box>
            
            {/* Action Buttons */}
            <Box sx={{ display: 'flex', gap: 2, mb: 3 }}>
              <Button 
                variant="contained" 
                size="large"
                startIcon={<ShoppingCartIcon />}
                fullWidth
              >
                Add to Cart
              </Button>
              <Button 
                variant="outlined" 
                size="large"
                startIcon={<FavoriteIcon />}
              >
                Wishlist
              </Button>
              <IconButton color="primary">
                <ShareIcon />
              </IconButton>
            </Box>
            
            {/* Features */}
            <Typography variant="h6" gutterBottom>
              Key Features
            </Typography>
            <Box component="ul" sx={{ pl: 2, mb: 3 }}>
              {product.features.map((feature, index) => (
                <Typography component="li" key={index} sx={{ mb: 0.5 }}>
                  {feature}
                </Typography>
              ))}
            </Box>
          </Box>
        </Grid>
      </Grid>

      {/* Product Tabs */}
      <Box sx={{ mb: 6 }}>
        <Tabs 
          value={activeTab} 
          onChange={handleTabChange} 
          variant="scrollable"
          scrollButtons="auto"
          sx={{ mb: 3, borderBottom: 1, borderColor: 'divider' }}
        >
          <Tab label="Specifications" />
          <Tab label="Reviews" />
          <Tab label="Shipping & Returns" />
        </Tabs>
        
        {/* Specifications Tab */}
        {activeTab === 0 && (
          <Box>
            <Typography variant="h6" gutterBottom>
              Technical Specifications
            </Typography>
            <Grid container spacing={2}>
              {Object.entries(product.specifications).map(([key, value]) => (
                <React.Fragment key={key}>
                  <Grid item xs={12} sm={4} md={3}>
                    <Typography variant="body1" fontWeight="bold">
                      {key}
                    </Typography>
                  </Grid>
                  <Grid item xs={12} sm={8} md={9}>
                    <Typography variant="body1">
                      {value}
                    </Typography>
                  </Grid>
                </React.Fragment>
              ))}
            </Grid>
          </Box>
        )}
        
        {/* Reviews Tab */}
        {activeTab === 1 && (
          <Box>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
              <Typography variant="h6">
                Customer Reviews ({product.reviewCount})
              </Typography>
              <Button variant="contained">Write a Review</Button>
            </Box>
            
            <Box sx={{ mb: 4 }}>
              {product.reviews.map((review) => (
                <Box key={review.id} sx={{ mb: 3, pb: 3, borderBottom: 1, borderColor: 'divider' }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                    <Avatar src={review.avatar} alt={review.user} sx={{ mr: 2 }} />
                    <Box>
                      <Typography variant="subtitle1">
                        {review.user}
                      </Typography>
                      <Box sx={{ display: 'flex', alignItems: 'center' }}>
                        <Rating value={review.rating} size="small" readOnly />
                        <Typography variant="body2" color="text.secondary" sx={{ ml: 1 }}>
                          {review.date}
                        </Typography>
                      </Box>
                    </Box>
                  </Box>
                  <Typography variant="body1">
                    {review.comment}
                  </Typography>
                </Box>
              ))}
            </Box>
            
            <Box sx={{ display: 'flex', justifyContent: 'center' }}>
              <Button variant="outlined">Load More Reviews</Button>
            </Box>
          </Box>
        )}
        
        {/* Shipping Tab */}
        {activeTab === 2 && (
          <Box>
            <Typography variant="h6" gutterBottom>
              Shipping Information
            </Typography>
            <Typography variant="body1" paragraph>
              We offer free standard shipping on all orders over $50. Orders typically process within 1-2 business days.
            </Typography>
            <Typography variant="body1" paragraph>
              Standard shipping (5-7 business days): FREE for orders over $50, $4.99 for orders under $50.
            </Typography>
            <Typography variant="body1" paragraph>
              Express shipping (2-3 business days): $12.99
            </Typography>
            
            <Typography variant="h6" gutterBottom sx={{ mt: 3 }}>
              Return Policy
            </Typography>
            <Typography variant="body1" paragraph>
              We accept returns within 30 days of delivery for a full refund or exchange. Items must be in original condition with all packaging and tags.
            </Typography>
            <Typography variant="body1">
              Please note that certain items like earphones, headphones, and personal care products cannot be returned once opened due to hygiene reasons.
            </Typography>
          </Box>
        )}
      </Box>

      {/* Related Products */}
      <Box sx={{ mb: 6 }}>
        <Typography variant="h5" gutterBottom sx={{ mb: 3 }}>
          You May Also Like
        </Typography>
        <Grid container spacing={3}>
          {relatedProducts.map((product) => (
            <Grid item xs={6} sm={3} key={product.id}>
              <Card 
                className="hover-scale" 
                sx={{ height: '100%' }}
                component={RouterLink}
                to={`/products/${product.id}`}
                sx={{
                  textDecoration: 'none',
                  color: 'inherit',
                  height: '100%',
                  display: 'flex',
                  flexDirection: 'column'
                }}
              >
                <CardMedia
                  component="img"
                  height="160"
                  image={product.image}
                  alt={product.name}
                />
                <CardContent>
                  <Typography variant="body2" color="text.secondary" gutterBottom>
                    {product.category}
                  </Typography>
                  <Typography variant="subtitle1" component="div" gutterBottom>
                    {product.name}
                  </Typography>
                  <Rating value={product.rating} size="small" precision={0.5} readOnly />
                  <Typography variant="subtitle1" color="primary" sx={{ mt: 1 }}>
                    ${product.price}
                  </Typography>
                </CardContent>
              </Card>
            </Grid>
          ))}
        </Grid>
      </Box>
    </Container>
  );
};

export default ProductDetailPage;
