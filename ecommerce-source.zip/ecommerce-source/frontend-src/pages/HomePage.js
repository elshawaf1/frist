import React from 'react';
import { Box, Typography, Grid, Card, CardMedia, CardContent, Button, Container, Rating } from '@mui/material';
import Slider from 'react-slick';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import FavoriteIcon from '@mui/icons-material/Favorite';

const HomePage = () => {
  // Settings for the hero slider
  const heroSettings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 5000,
  };

  // Settings for the featured products slider
  const productSettings = {
    dots: false,
    infinite: true,
    speed: 500,
    slidesToShow: 4,
    slidesToScroll: 1,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 3,
        }
      },
      {
        breakpoint: 768,
        settings: {
          slidesToShow: 2,
        }
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1,
        }
      }
    ]
  };

  // Dummy featured products
  const featuredProducts = [
    {
      id: 1,
      name: 'Wireless Headphones',
      price: 129.99,
      rating: 4.5,
      image: 'https://via.placeholder.com/300x300',
      category: 'Electronics'
    },
    {
      id: 2,
      name: 'Smart Watch',
      price: 199.99,
      rating: 4.2,
      image: 'https://via.placeholder.com/300x300',
      category: 'Electronics'
    },
    {
      id: 3,
      name: 'Running Shoes',
      price: 89.99,
      rating: 4.7,
      image: 'https://via.placeholder.com/300x300',
      category: 'Fashion'
    },
    {
      id: 4,
      name: 'Laptop Backpack',
      price: 59.99,
      rating: 4.3,
      image: 'https://via.placeholder.com/300x300',
      category: 'Accessories'
    },
    {
      id: 5,
      name: 'Coffee Maker',
      price: 79.99,
      rating: 4.6,
      image: 'https://via.placeholder.com/300x300',
      category: 'Home'
    }
  ];

  // Dummy categories
  const categories = [
    { id: 1, name: 'Electronics', image: 'https://via.placeholder.com/200x200' },
    { id: 2, name: 'Fashion', image: 'https://via.placeholder.com/200x200' },
    { id: 3, name: 'Home & Kitchen', image: 'https://via.placeholder.com/200x200' },
    { id: 4, name: 'Beauty', image: 'https://via.placeholder.com/200x200' },
    { id: 5, name: 'Sports', image: 'https://via.placeholder.com/200x200' },
    { id: 6, name: 'Books', image: 'https://via.placeholder.com/200x200' },
  ];

  return (
    <Box className="fade-in">
      {/* Hero Slider */}
      <Box sx={{ mb: 6 }}>
        <Slider {...heroSettings}>
          <Box sx={{ position: 'relative', height: { xs: '300px', md: '500px' } }}>
            <Box
              sx={{
                position: 'absolute',
                top: 0,
                left: 0,
                width: '100%',
                height: '100%',
                backgroundImage: 'url(https://via.placeholder.com/1920x500)',
                backgroundSize: 'cover',
                backgroundPosition: 'center',
              }}
            />
            <Box
              sx={{
                position: 'absolute',
                top: 0,
                left: 0,
                width: '100%',
                height: '100%',
                backgroundColor: 'rgba(0,0,0,0.4)',
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'center',
                padding: 4,
              }}
            >
              <Container>
                <Typography variant="h2" color="white" gutterBottom>
                  Summer Collection 2025
                </Typography>
                <Typography variant="h5" color="white" sx={{ mb: 3 }}>
                  Discover the latest trends and styles
                </Typography>
                <Button variant="contained" size="large">
                  Shop Now
                </Button>
              </Container>
            </Box>
          </Box>
          <Box sx={{ position: 'relative', height: { xs: '300px', md: '500px' } }}>
            <Box
              sx={{
                position: 'absolute',
                top: 0,
                left: 0,
                width: '100%',
                height: '100%',
                backgroundImage: 'url(https://via.placeholder.com/1920x500)',
                backgroundSize: 'cover',
                backgroundPosition: 'center',
              }}
            />
            <Box
              sx={{
                position: 'absolute',
                top: 0,
                left: 0,
                width: '100%',
                height: '100%',
                backgroundColor: 'rgba(0,0,0,0.4)',
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'center',
                padding: 4,
              }}
            >
              <Container>
                <Typography variant="h2" color="white" gutterBottom>
                  New Electronics
                </Typography>
                <Typography variant="h5" color="white" sx={{ mb: 3 }}>
                  The latest gadgets with amazing deals
                </Typography>
                <Button variant="contained" size="large">
                  Explore
                </Button>
              </Container>
            </Box>
          </Box>
        </Slider>
      </Box>

      {/* Featured Categories */}
      <Container sx={{ mb: 8 }}>
        <Typography variant="h4" gutterBottom sx={{ mb: 4 }}>
          Shop by Category
        </Typography>
        <Grid container spacing={3}>
          {categories.map((category) => (
            <Grid item xs={6} sm={4} md={2} key={category.id}>
              <Card className="hover-scale layered-card" sx={{ height: '100%' }}>
                <CardMedia
                  component="img"
                  height="140"
                  image={category.image}
                  alt={category.name}
                />
                <CardContent sx={{ textAlign: 'center' }}>
                  <Typography variant="h6" component="div">
                    {category.name}
                  </Typography>
                </CardContent>
              </Card>
            </Grid>
          ))}
        </Grid>
      </Container>

      {/* Featured Products */}
      <Box sx={{ backgroundColor: '#f5f5f5', py: 6, mb: 8 }}>
        <Container>
          <Typography variant="h4" gutterBottom sx={{ mb: 4 }}>
            Featured Products
          </Typography>
          <Slider {...productSettings}>
            {featuredProducts.map((product) => (
              <Box key={product.id} sx={{ px: 1 }}>
                <Card className="hover-scale" sx={{ height: '100%' }}>
                  <CardMedia
                    component="img"
                    height="200"
                    image={product.image}
                    alt={product.name}
                  />
                  <CardContent>
                    <Typography variant="body2" color="text.secondary" gutterBottom>
                      {product.category}
                    </Typography>
                    <Typography variant="h6" component="div" gutterBottom>
                      {product.name}
                    </Typography>
                    <Rating value={product.rating} precision={0.5} size="small" readOnly />
                    <Typography variant="h6" color="primary" sx={{ mt: 1, mb: 2 }}>
                      ${product.price}
                    </Typography>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                      <Button 
                        variant="contained" 
                        startIcon={<ShoppingCartIcon />}
                        size="small"
                        sx={{ flexGrow: 1, mr: 1 }}
                      >
                        Add
                      </Button>
                      <Button 
                        variant="outlined" 
                        color="secondary"
                        size="small"
                      >
                        <FavoriteIcon />
                      </Button>
                    </Box>
                  </CardContent>
                </Card>
              </Box>
            ))}
          </Slider>
        </Container>
      </Box>

      {/* Features Section */}
      <Container sx={{ mb: 8 }}>
        <Grid container spacing={4}>
          <Grid item xs={12} md={4}>
            <Box sx={{ textAlign: 'center', p: 3 }}>
              <img src="https://via.placeholder.com/80" alt="Fast Shipping" style={{ marginBottom: 16 }} />
              <Typography variant="h6" gutterBottom>
                Fast Shipping
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Free shipping on all orders over $50
              </Typography>
            </Box>
          </Grid>
          <Grid item xs={12} md={4}>
            <Box sx={{ textAlign: 'center', p: 3 }}>
              <img src="https://via.placeholder.com/80" alt="Secure Payment" style={{ marginBottom: 16 }} />
              <Typography variant="h6" gutterBottom>
                Secure Payment
              </Typography>
              <Typography variant="body2" color="text.secondary">
                100% secure payment methods
              </Typography>
            </Box>
          </Grid>
          <Grid item xs={12} md={4}>
            <Box sx={{ textAlign: 'center', p: 3 }}>
              <img src="https://via.placeholder.com/80" alt="24/7 Support" style={{ marginBottom: 16 }} />
              <Typography variant="h6" gutterBottom>
                24/7 Support
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Dedicated support team available anytime
              </Typography>
            </Box>
          </Grid>
        </Grid>
      </Container>

      {/* Newsletter Section */}
      <Box sx={{ backgroundColor: 'primary.main', color: 'white', py: 6, mb: 8 }}>
        <Container>
          <Grid container spacing={4} alignItems="center">
            <Grid item xs={12} md={6}>
              <Typography variant="h4" gutterBottom>
                Subscribe to Our Newsletter
              </Typography>
              <Typography variant="body1" sx={{ mb: 3 }}>
                Get the latest updates on new products and upcoming sales
              </Typography>
            </Grid>
            <Grid item xs={12} md={6}>
              <Box sx={{ display: 'flex', gap: 1 }}>
                <input
                  type="email"
                  placeholder="Your email address"
                  style={{
                    padding: '12px 16px',
                    borderRadius: '4px',
                    border: 'none',
                    flexGrow: 1,
                    fontSize: '16px',
                  }}
                />
                <Button variant="contained" color="secondary" size="large">
                  Subscribe
                </Button>
              </Box>
            </Grid>
          </Grid>
        </Container>
      </Box>
    </Box>
  );
};

export default HomePage;
