import React, { useState, useEffect } from 'react';
import { 
  Box, 
  Container, 
  Typography, 
  Grid, 
  Card, 
  CardMedia, 
  CardContent, 
  Button, 
  TextField,
  InputAdornment,
  IconButton,
  Pagination,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Slider,
  Chip,
  Divider
} from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import FilterListIcon from '@mui/icons-material/FilterList';
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import FavoriteIcon from '@mui/icons-material/Favorite';
import { Link as RouterLink } from 'react-router-dom';

const ProductsPage = () => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [category, setCategory] = useState('');
  const [sortBy, setSortBy] = useState('');
  const [priceRange, setPriceRange] = useState([0, 1000]);
  const [searchTerm, setSearchTerm] = useState('');
  const [showFilters, setShowFilters] = useState(false);

  // Dummy products data
  const dummyProducts = [
    {
      id: 1,
      name: 'Wireless Headphones',
      price: 129.99,
      rating: 4.5,
      image: 'https://via.placeholder.com/300x300',
      category: 'Electronics',
      description: 'High-quality wireless headphones with noise cancellation.'
    },
    {
      id: 2,
      name: 'Smart Watch',
      price: 199.99,
      rating: 4.2,
      image: 'https://via.placeholder.com/300x300',
      category: 'Electronics',
      description: 'Feature-rich smartwatch with health monitoring.'
    },
    {
      id: 3,
      name: 'Running Shoes',
      price: 89.99,
      rating: 4.7,
      image: 'https://via.placeholder.com/300x300',
      category: 'Fashion',
      description: 'Comfortable running shoes with excellent support.'
    },
    {
      id: 4,
      name: 'Laptop Backpack',
      price: 59.99,
      rating: 4.3,
      image: 'https://via.placeholder.com/300x300',
      category: 'Accessories',
      description: 'Durable laptop backpack with multiple compartments.'
    },
    {
      id: 5,
      name: 'Coffee Maker',
      price: 79.99,
      rating: 4.6,
      image: 'https://via.placeholder.com/300x300',
      category: 'Home',
      description: 'Programmable coffee maker for perfect brews.'
    },
    {
      id: 6,
      name: 'Bluetooth Speaker',
      price: 49.99,
      rating: 4.1,
      image: 'https://via.placeholder.com/300x300',
      category: 'Electronics',
      description: 'Portable Bluetooth speaker with rich sound.'
    },
    {
      id: 7,
      name: 'Yoga Mat',
      price: 29.99,
      rating: 4.8,
      image: 'https://via.placeholder.com/300x300',
      category: 'Sports',
      description: 'Non-slip yoga mat for comfortable workouts.'
    },
    {
      id: 8,
      name: 'Desk Lamp',
      price: 39.99,
      rating: 4.4,
      image: 'https://via.placeholder.com/300x300',
      category: 'Home',
      description: 'Adjustable desk lamp with multiple brightness levels.'
    },
    {
      id: 9,
      name: 'Wireless Mouse',
      price: 24.99,
      rating: 4.2,
      image: 'https://via.placeholder.com/300x300',
      category: 'Electronics',
      description: 'Ergonomic wireless mouse for comfortable use.'
    },
    {
      id: 10,
      name: 'Water Bottle',
      price: 19.99,
      rating: 4.5,
      image: 'https://via.placeholder.com/300x300',
      category: 'Sports',
      description: 'Insulated water bottle that keeps drinks cold for hours.'
    },
    {
      id: 11,
      name: 'Smartphone Case',
      price: 14.99,
      rating: 4.0,
      image: 'https://via.placeholder.com/300x300',
      category: 'Accessories',
      description: 'Protective smartphone case with sleek design.'
    },
    {
      id: 12,
      name: 'Portable Charger',
      price: 34.99,
      rating: 4.6,
      image: 'https://via.placeholder.com/300x300',
      category: 'Electronics',
      description: 'High-capacity portable charger for all your devices.'
    }
  ];

  // Categories
  const categories = [
    'All',
    'Electronics',
    'Fashion',
    'Home',
    'Sports',
    'Accessories'
  ];

  // Sort options
  const sortOptions = [
    { value: 'price_asc', label: 'Price: Low to High' },
    { value: 'price_desc', label: 'Price: High to Low' },
    { value: 'rating_desc', label: 'Highest Rated' },
    { value: 'newest', label: 'Newest Arrivals' }
  ];

  // Load products
  useEffect(() => {
    // Simulate API call
    setTimeout(() => {
      setProducts(dummyProducts);
      setLoading(false);
    }, 500);
  }, []);

  // Filter products
  const filteredProducts = products.filter(product => {
    const matchesCategory = category === '' || category === 'All' || product.category === category;
    const matchesPrice = product.price >= priceRange[0] && product.price <= priceRange[1];
    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          product.description.toLowerCase().includes(searchTerm.toLowerCase());
    
    return matchesCategory && matchesPrice && matchesSearch;
  });

  // Sort products
  const sortedProducts = [...filteredProducts].sort((a, b) => {
    if (sortBy === 'price_asc') return a.price - b.price;
    if (sortBy === 'price_desc') return b.price - a.price;
    if (sortBy === 'rating_desc') return b.rating - a.rating;
    if (sortBy === 'newest') return b.id - a.id;
    return 0;
  });

  // Pagination
  const productsPerPage = 8;
  const totalPages = Math.ceil(sortedProducts.length / productsPerPage);
  const displayedProducts = sortedProducts.slice(
    (page - 1) * productsPerPage,
    page * productsPerPage
  );

  const handlePageChange = (event, value) => {
    setPage(value);
    window.scrollTo(0, 0);
  };

  const handlePriceChange = (event, newValue) => {
    setPriceRange(newValue);
  };

  const handleCategoryChange = (event) => {
    setCategory(event.target.value);
    setPage(1);
  };

  const handleSortChange = (event) => {
    setSortBy(event.target.value);
  };

  const handleSearchChange = (event) => {
    setSearchTerm(event.target.value);
    setPage(1);
  };

  const toggleFilters = () => {
    setShowFilters(!showFilters);
  };

  return (
    <Container className="fade-in">
      <Box sx={{ mb: 4 }}>
        <Typography variant="h4" gutterBottom>
          Products
        </Typography>
        <Typography variant="body1" color="text.secondary">
          Discover our wide range of products
        </Typography>
      </Box>

      {/* Search and Filter Bar */}
      <Box sx={{ mb: 4 }}>
        <Grid container spacing={2} alignItems="center">
          <Grid item xs={12} md={6}>
            <TextField
              fullWidth
              placeholder="Search products..."
              value={searchTerm}
              onChange={handleSearchChange}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <SearchIcon />
                  </InputAdornment>
                ),
              }}
            />
          </Grid>
          <Grid item xs={6} md={3}>
            <FormControl fullWidth>
              <InputLabel>Sort By</InputLabel>
              <Select
                value={sortBy}
                label="Sort By"
                onChange={handleSortChange}
              >
                {sortOptions.map((option) => (
                  <MenuItem key={option.value} value={option.value}>
                    {option.label}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={6} md={3}>
            <Button 
              fullWidth 
              variant="outlined" 
              startIcon={<FilterListIcon />}
              onClick={toggleFilters}
            >
              Filters
            </Button>
          </Grid>
        </Grid>
      </Box>

      {/* Filters Section */}
      {showFilters && (
        <Box sx={{ mb: 4, p: 2, border: '1px solid #e0e0e0', borderRadius: 1 }}>
          <Grid container spacing={3}>
            <Grid item xs={12} md={6}>
              <Typography variant="subtitle1" gutterBottom>
                Category
              </Typography>
              <FormControl fullWidth>
                <Select
                  value={category}
                  onChange={handleCategoryChange}
                  displayEmpty
                >
                  <MenuItem value="">All Categories</MenuItem>
                  {categories.map((cat) => (
                    <MenuItem key={cat} value={cat}>
                      {cat}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12} md={6}>
              <Typography variant="subtitle1" gutterBottom>
                Price Range: ${priceRange[0]} - ${priceRange[1]}
              </Typography>
              <Slider
                value={priceRange}
                onChange={handlePriceChange}
                valueLabelDisplay="auto"
                min={0}
                max={1000}
              />
            </Grid>
          </Grid>
          <Box sx={{ mt: 2, display: 'flex', justifyContent: 'flex-end' }}>
            <Button 
              variant="contained" 
              onClick={() => {
                setCategory('');
                setPriceRange([0, 1000]);
                setSearchTerm('');
                setSortBy('');
                setPage(1);
              }}
            >
              Clear Filters
            </Button>
          </Box>
        </Box>
      )}

      {/* Active Filters */}
      {(category || searchTerm || sortBy || priceRange[0] > 0 || priceRange[1] < 1000) && (
        <Box sx={{ mb: 3, display: 'flex', flexWrap: 'wrap', gap: 1 }}>
          <Typography variant="body2" sx={{ mr: 1, alignSelf: 'center' }}>
            Active Filters:
          </Typography>
          {category && (
            <Chip 
              label={`Category: ${category}`} 
              onDelete={() => setCategory('')}
              size="small"
            />
          )}
          {searchTerm && (
            <Chip 
              label={`Search: ${searchTerm}`} 
              onDelete={() => setSearchTerm('')}
              size="small"
            />
          )}
          {(priceRange[0] > 0 || priceRange[1] < 1000) && (
            <Chip 
              label={`Price: $${priceRange[0]} - $${priceRange[1]}`} 
              onDelete={() => setPriceRange([0, 1000])}
              size="small"
            />
          )}
        </Box>
      )}

      {/* Products Grid */}
      {loading ? (
        <Box sx={{ display: 'flex', justifyContent: 'center', my: 4 }}>
          <Typography>Loading products...</Typography>
        </Box>
      ) : displayedProducts.length === 0 ? (
        <Box sx={{ display: 'flex', justifyContent: 'center', my: 4 }}>
          <Typography>No products found matching your criteria.</Typography>
        </Box>
      ) : (
        <>
          <Grid container spacing={3}>
            {displayedProducts.map((product) => (
              <Grid item xs={12} sm={6} md={3} key={product.id}>
                <Card 
                  className="hover-scale" 
                  sx={{ 
                    height: '100%',
                    display: 'flex',
                    flexDirection: 'column'
                  }}
                  component={RouterLink}
                  to={`/products/${product.id}`}
                  sx={{
                    textDecoration: 'none',
                    color: 'inherit',
                    height: '100%',
                    display: 'flex',
                    flexDirection: 'column'
                  }}
                >
                  <CardMedia
                    component="img"
                    height="200"
                    image={product.image}
                    alt={product.name}
                  />
                  <CardContent sx={{ flexGrow: 1 }}>
                    <Typography variant="body2" color="text.secondary" gutterBottom>
                      {product.category}
                    </Typography>
                    <Typography variant="h6" component="div" gutterBottom>
                      {product.name}
                    </Typography>
                    <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                      {product.description.substring(0, 60)}...
                    </Typography>
                    <Typography variant="h6" color="primary" sx={{ mt: 'auto' }}>
                      ${product.price}
                    </Typography>
                  </CardContent>
                  <Box sx={{ p: 2, pt: 0, mt: 'auto' }}>
                    <Button 
                      variant="contained" 
                      fullWidth
                      startIcon={<ShoppingCartIcon />}
                      onClick={(e) => {
                        e.preventDefault();
                        // Add to cart logic
                      }}
                    >
                      Add to Cart
                    </Button>
                    <Button 
                      variant="outlined" 
                      fullWidth
                      startIcon={<FavoriteIcon />}
                      sx={{ mt: 1 }}
                      onClick={(e) => {
                        e.preventDefault();
                        // Add to wishlist logic
                      }}
                    >
                      Wishlist
                    </Button>
                  </Box>
                </Card>
              </Grid>
            ))}
          </Grid>

          {/* Pagination */}
          {totalPages > 1 && (
            <Box sx={{ display: 'flex', justifyContent: 'center', mt: 4 }}>
              <Pagination 
                count={totalPages} 
                page={page} 
                onChange={handlePageChange} 
                color="primary" 
              />
            </Box>
          )}
        </>
      )}
    </Container>
  );
};

export default ProductsPage;
