import React, { useState } from 'react';
import { 
  Box, 
  Container, 
  Typography, 
  Grid, 
  Card, 
  CardContent, 
  Button, 
  Stepper,
  Step,
  StepLabel,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  FormControlLabel,
  Checkbox,
  Divider,
  Radio,
  RadioGroup,
  Paper
} from '@mui/material';
import { Link as RouterLink } from 'react-router-dom';

const CheckoutPage = () => {
  const [activeStep, setActiveStep] = useState(0);
  const [formData, setFormData] = useState({
    // Shipping information
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    state: '',
    zipCode: '',
    country: 'US',
    // Payment information
    cardName: '',
    cardNumber: '',
    expiryDate: '',
    cvv: '',
    savePaymentInfo: false,
    // Shipping method
    shippingMethod: 'standard'
  });
  
  // Sample cart items
  const cartItems = [
    {
      id: 1,
      name: 'Wireless Headphones',
      price: 129.99,
      image: 'https://via.placeholder.com/100x100',
      quantity: 1
    },
    {
      id: 2,
      name: 'Smart Watch',
      price: 199.99,
      image: 'https://via.placeholder.com/100x100',
      quantity: 2
    },
    {
      id: 3,
      name: 'Laptop Backpack',
      price: 59.99,
      image: 'https://via.placeholder.com/100x100',
      quantity: 1
    }
  ];

  // Calculate order summary
  const subtotal = cartItems.reduce((total, item) => total + (item.price * item.quantity), 0);
  const shipping = formData.shippingMethod === 'express' ? 19.99 : (formData.shippingMethod === 'standard' ? 9.99 : 0);
  const tax = subtotal * 0.08;
  const total = subtotal + shipping + tax;

  const steps = ['Shipping', 'Payment', 'Review'];

  const handleChange = (e) => {
    const { name, value, checked, type } = e.target;
    setFormData({
      ...formData,
      [name]: type === 'checkbox' ? checked : value
    });
  };

  const handleNext = () => {
    setActiveStep((prevActiveStep) => prevActiveStep + 1);
  };

  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Process the order
    console.log('Order submitted:', { formData, cartItems, total });
    // Move to confirmation step
    setActiveStep(3);
  };

  return (
    <Container className="fade-in" sx={{ py: 4 }}>
      <Typography variant="h4" gutterBottom>
        Checkout
      </Typography>
      
      <Stepper activeStep={activeStep} sx={{ mb: 4 }}>
        {steps.map((label) => (
          <Step key={label}>
            <StepLabel>{label}</StepLabel>
          </Step>
        ))}
      </Stepper>
      
      <Grid container spacing={4}>
        {/* Checkout Form */}
        <Grid item xs={12} md={8}>
          {activeStep === 3 ? (
            <Paper sx={{ p: 4, borderRadius: 2, textAlign: 'center' }}>
              <Typography variant="h5" gutterBottom color="primary">
                Thank you for your order!
              </Typography>
              <Typography variant="body1" paragraph>
                Your order has been placed successfully. We've sent you an email with all the details.
              </Typography>
              <Typography variant="body1" paragraph>
                Order number: <strong>#ORD-{Math.floor(100000 + Math.random() * 900000)}</strong>
              </Typography>
              <Button 
                component={RouterLink} 
                to="/" 
                variant="contained" 
                sx={{ mt: 2 }}
              >
                Continue Shopping
              </Button>
            </Paper>
          ) : (
            <Box component="form" onSubmit={activeStep === 2 ? handleSubmit : handleNext}>
              {/* Shipping Information */}
              {activeStep === 0 && (
                <Card sx={{ borderRadius: 2, mb: 4 }}>
                  <CardContent>
                    <Typography variant="h6" gutterBottom>
                      Shipping Information
                    </Typography>
                    <Grid container spacing={2}>
                      <Grid item xs={12} sm={6}>
                        <TextField
                          required
                          fullWidth
                          label="First Name"
                          name="firstName"
                          value={formData.firstName}
                          onChange={handleChange}
                        />
                      </Grid>
                      <Grid item xs={12} sm={6}>
                        <TextField
                          required
                          fullWidth
                          label="Last Name"
                          name="lastName"
                          value={formData.lastName}
                          onChange={handleChange}
                        />
                      </Grid>
                      <Grid item xs={12} sm={6}>
                        <TextField
                          required
                          fullWidth
                          label="Email"
                          name="email"
                          type="email"
                          value={formData.email}
                          onChange={handleChange}
                        />
                      </Grid>
                      <Grid item xs={12} sm={6}>
                        <TextField
                          required
                          fullWidth
                          label="Phone"
                          name="phone"
                          value={formData.phone}
                          onChange={handleChange}
                        />
                      </Grid>
                      <Grid item xs={12}>
                        <TextField
                          required
                          fullWidth
                          label="Address"
                          name="address"
                          value={formData.address}
                          onChange={handleChange}
                        />
                      </Grid>
                      <Grid item xs={12} sm={6}>
                        <TextField
                          required
                          fullWidth
                          label="City"
                          name="city"
                          value={formData.city}
                          onChange={handleChange}
                        />
                      </Grid>
                      <Grid item xs={12} sm={6}>
                        <TextField
                          required
                          fullWidth
                          label="State/Province"
                          name="state"
                          value={formData.state}
                          onChange={handleChange}
                        />
                      </Grid>
                      <Grid item xs={12} sm={6}>
                        <TextField
                          required
                          fullWidth
                          label="ZIP / Postal Code"
                          name="zipCode"
                          value={formData.zipCode}
                          onChange={handleChange}
                        />
                      </Grid>
                      <Grid item xs={12} sm={6}>
                        <FormControl fullWidth required>
                          <InputLabel>Country</InputLabel>
                          <Select
                            name="country"
                            value={formData.country}
                            onChange={handleChange}
                            label="Country"
                          >
                            <MenuItem value="US">United States</MenuItem>
                            <MenuItem value="CA">Canada</MenuItem>
                            <MenuItem value="UK">United Kingdom</MenuItem>
                            <MenuItem value="AU">Australia</MenuItem>
                          </Select>
                        </FormControl>
                      </Grid>
                    </Grid>
                  </CardContent>
                </Card>
              )}
              
              {/* Shipping Method */}
              {activeStep === 0 && (
                <Card sx={{ borderRadius: 2 }}>
                  <CardContent>
                    <Typography variant="h6" gutterBottom>
                      Shipping Method
                    </Typography>
                    <RadioGroup
                      name="shippingMethod"
                      value={formData.shippingMethod}
                      onChange={handleChange}
                    >
                      <FormControlLabel 
                        value="standard" 
                        control={<Radio />} 
                        label={
                          <Box>
                            <Typography variant="body1">Standard Shipping ($9.99)</Typography>
                            <Typography variant="body2" color="text.secondary">
                              Delivery in 5-7 business days
                            </Typography>
                          </Box>
                        } 
                      />
                      <FormControlLabel 
                        value="express" 
                        control={<Radio />} 
                        label={
                          <Box>
                            <Typography variant="body1">Express Shipping ($19.99)</Typography>
                            <Typography variant="body2" color="text.secondary">
                              Delivery in 2-3 business days
                            </Typography>
                          </Box>
                        } 
                      />
                      <FormControlLabel 
                        value="free" 
                        control={<Radio />} 
                        label={
                          <Box>
                            <Typography variant="body1">Free Shipping</Typography>
                            <Typography variant="body2" color="text.secondary">
                              Delivery in 7-10 business days
                            </Typography>
                          </Box>
                        } 
                      />
                    </RadioGroup>
                  </CardContent>
                </Card>
              )}
              
              {/* Payment Information */}
              {activeStep === 1 && (
                <Card sx={{ borderRadius: 2 }}>
                  <CardContent>
                    <Typography variant="h6" gutterBottom>
                      Payment Information
                    </Typography>
                    <Grid container spacing={2}>
                      <Grid item xs={12}>
                        <TextField
                          required
                          fullWidth
                          label="Name on Card"
                          name="cardName"
                          value={formData.cardName}
                          onChange={handleChange}
                        />
                      </Grid>
                      <Grid item xs={12}>
                        <TextField
                          required
                          fullWidth
                          label="Card Number"
                          name="cardNumber"
                          value={formData.cardNumber}
                          onChange={handleChange}
                          placeholder="XXXX XXXX XXXX XXXX"
                        />
                      </Grid>
                      <Grid item xs={12} sm={6}>
                        <TextField
                          required
                          fullWidth
                          label="Expiry Date"
                          name="expiryDate"
                          value={formData.expiryDate}
                          onChange={handleChange}
                          placeholder="MM/YY"
                        />
                      </Grid>
                      <Grid item xs={12} sm={6}>
                        <TextField
                          required
                          fullWidth
                          label="CVV"
                          name="cvv"
                          value={formData.cvv}
                          onChange={handleChange}
                          placeholder="XXX"
                        />
                      </Grid>
                      <Grid item xs={12}>
                        <FormControlLabel
                          control={
                            <Checkbox
                              name="savePaymentInfo"
                              checked={formData.savePaymentInfo}
                              onChange={handleChange}
                              color="primary"
                            />
                          }
                          label="Save this card for future purchases"
                        />
                      </Grid>
                    </Grid>
                    
                    <Box sx={{ mt: 3, display: 'flex', justifyContent: 'center' }}>
                      <Box component="img" src="https://via.placeholder.com/40x25" alt="Visa" sx={{ mx: 0.5 }} />
                      <Box component="img" src="https://via.placeholder.com/40x25" alt="Mastercard" sx={{ mx: 0.5 }} />
                      <Box component="img" src="https://via.placeholder.com/40x25" alt="Amex" sx={{ mx: 0.5 }} />
                      <Box component="img" src="https://via.placeholder.com/40x25" alt="PayPal" sx={{ mx: 0.5 }} />
                    </Box>
                  </CardContent>
                </Card>
              )}
              
              {/* Order Review */}
              {activeStep === 2 && (
                <Card sx={{ borderRadius: 2 }}>
                  <CardContent>
                    <Typography variant="h6" gutterBottom>
                      Order Review
                    </Typography>
                    
                    <Typography variant="subtitle1" gutterBottom sx={{ mt: 2 }}>
                      Shipping Information
                    </Typography>
                    <Typography variant="body1">
                      {formData.firstName} {formData.lastName}
                    </Typography>
                    <Typography variant="body1">
                      {formData.address}
                    </Typography>
                    <Typography variant="body1">
                      {formData.city}, {formData.state} {formData.zipCode}
                    </Typography>
                    <Typography variant="body1">
                      {formData.country}
                    </Typography>
                    <Typography variant="body1">
                      {formData.email}
                    </Typography>
                    <Typography variant="body1">
                      {formData.phone}
                    </Typography>
                    
                    <Typography variant="subtitle1" gutterBottom sx={{ mt: 3 }}>
                      Shipping Method
                    </Typography>
                    <Typography variant="body1">
                      {formData.shippingMethod === 'express' 
                        ? 'Express Shipping (2-3 business days)' 
                        : formData.shippingMethod === 'standard'
                          ? 'Standard Shipping (5-7 business days)'
                          : 'Free Shipping (7-10 business days)'}
                    </Typography>
                    
                    <Typography variant="subtitle1" gutterBottom sx={{ mt: 3 }}>
                      Payment Method
                    </Typography>
                    <Typography variant="body1">
                      {formData.cardName}
                    </Typography>
                    <Typography variant="body1">
                      Card ending in {formData.cardNumber.slice(-4)}
                    </Typography>
                    
                    <Typography variant="subtitle1" gutterBottom sx={{ mt: 3 }}>
                      Order Items
                    </Typography>
                    {cartItems.map((item) => (
                      <Box key={item.id} sx={{ display: 'flex', mb: 2 }}>
                        <Box
                          component="img"
                          src={item.image}
                          alt={item.name}
                          sx={{ width: 60, height: 60, mr: 2, borderRadius: 1 }}
                        />
                        <Box sx={{ flexGrow: 1 }}>
                          <Typography variant="body1">
                            {item.name}
                          </Typography>
                          <Typography variant="body2" color="text.secondary">
                            Qty: {item.quantity}
                          </Typography>
                        </Box>
                        <Typography variant="body1">
                          ${(item.price * item.quantity).toFixed(2)}
                        </Typography>
                      </Box>
                    ))}
                  </CardContent>
                </Card>
              )}
              
              <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 3 }}>
                <Button
                  disabled={activeStep === 0}
                  onClick={handleBack}
                  variant="outlined"
                >
                  Back
                </Button>
                <Button
                  type={activeStep === 2 ? 'submit' : 'button'}
                  variant="contained"
                  color="primary"
                  onClick={activeStep === 2 ? undefined : handleNext}
                >
                  {activeStep === 2 ? 'Place Order' : 'Next'}
                </Button>
              </Box>
            </Box>
          )}
        </Grid>
        
        {/* Order Summary */}
        <Grid item xs={12} md={4}>
          <Card sx={{ borderRadius: 2, position: 'sticky', top: 20 }}>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Order Summary
              </Typography>
              
              {cartItems.map((item) => (
                <Box key={item.id} sx={{ display: 'flex', mb: 2 }}>
                  <Box
                    component="img"
                    src={item.image}
                    alt={item.name}
                    sx={{ width: 40, height: 40, mr: 2, borderRadius: 1 }}
                  />
                  <Box sx={{ flexGrow: 1 }}>
                    <Typography variant="body2">
                      {item.name} x {item.quantity}
                    </Typography>
                  </Box>
                  <Typography variant="body2">
                    ${(item.price * item.quantity).toFixed(2)}
                  </Typography>
                </Box>
              ))}
              
              <Divider sx={{ my: 2 }} />
              
              <Box sx={{ mb: 2 }}>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                  <Typography variant="body2">Subtotal</Typography>
                  <Typography variant="body2">${subtotal.toFixed(2)}</Typography>
                </Box>
                
                <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                  <Typography variant="body2">Shipping</Typography>
                  <Typography variant="body2">
                    {shipping === 0 ? 'Free' : `$${shipping.toFixed(2)}`}
                  </Typography>
                </Box>
                
                <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                  <Typography variant="body2">Tax</Typography>
                  <Typography variant="body2">${tax.toFixed(2)}</Typography>
                </Box>
              </Box>
              
              <Divider sx={{ my: 2 }} />
              
              <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                <Typography variant="subtitle1" fontWeight="bold">
                  Total
                </Typography>
                <Typography variant="subtitle1" fontWeight="bold">
                  ${total.toFixed(2)}
                </Typography>
              </Box>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Container>
  );
};

export default CheckoutPage;
