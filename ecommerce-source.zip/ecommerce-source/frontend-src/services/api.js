import axios from 'axios';

const API_URL = 'http://localhost:8000/api';

// Create axios instance with base URL
const apiClient = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Add interceptor to add auth token to requests
apiClient.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers['Authorization'] = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Authentication services
export const authService = {
  login: async (email, password) => {
    const response = await apiClient.post('/auth/login', { email, password });
    if (response.data.access_token) {
      localStorage.setItem('token', response.data.access_token);
    }
    return response.data;
  },
  
  register: async (userData) => {
    return await apiClient.post('/auth/register', userData);
  },
  
  logout: () => {
    localStorage.removeItem('token');
  },
  
  getCurrentUser: async () => {
    return await apiClient.get('/users/me');
  },
};

// Product services
export const productService = {
  getAllProducts: async (params) => {
    return await apiClient.get('/products', { params });
  },
  
  getProductById: async (id) => {
    return await apiClient.get(`/products/${id}`);
  },
  
  searchProducts: async (query) => {
    return await apiClient.get('/products/search', { params: { q: query } });
  },
  
  getProductsByCategory: async (category) => {
    return await apiClient.get('/products', { params: { category } });
  },
};

// Cart services
export const cartService = {
  getCart: async () => {
    return await apiClient.get('/cart');
  },
  
  addToCart: async (productId, quantity) => {
    return await apiClient.post('/cart/items', { product_id: productId, quantity });
  },
  
  updateCartItem: async (itemId, quantity) => {
    return await apiClient.put(`/cart/items/${itemId}`, { quantity });
  },
  
  removeFromCart: async (itemId) => {
    return await apiClient.delete(`/cart/items/${itemId}`);
  },
  
  clearCart: async () => {
    return await apiClient.delete('/cart');
  },
};

// Wishlist services
export const wishlistService = {
  getWishlist: async () => {
    return await apiClient.get('/wishlist');
  },
  
  addToWishlist: async (productId) => {
    return await apiClient.post('/wishlist/items', { product_id: productId });
  },
  
  removeFromWishlist: async (itemId) => {
    return await apiClient.delete(`/wishlist/items/${itemId}`);
  },
};

// Order services
export const orderService = {
  createOrder: async (orderData) => {
    return await apiClient.post('/orders', orderData);
  },
  
  getOrders: async () => {
    return await apiClient.get('/orders');
  },
  
  getOrderById: async (id) => {
    return await apiClient.get(`/orders/${id}`);
  },
};

// Review services
export const reviewService = {
  getProductReviews: async (productId) => {
    return await apiClient.get(`/products/${productId}/reviews`);
  },
  
  createReview: async (productId, reviewData) => {
    return await apiClient.post(`/products/${productId}/reviews`, reviewData);
  },
};

export default {
  auth: authService,
  products: productService,
  cart: cartService,
  wishlist: wishlistService,
  orders: orderService,
  reviews: reviewService,
};
