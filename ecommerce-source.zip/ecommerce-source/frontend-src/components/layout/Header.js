import React from 'react';
import { AppBar, Toolbar, Typography, Button, IconButton, Badge, Box, Container, useMediaQuery, Drawer, List, ListItem, ListItemText, ListItemIcon } from '@mui/material';
import { useTheme } from '@mui/material/styles';
import MenuIcon from '@mui/icons-material/Menu';
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import FavoriteIcon from '@mui/icons-material/Favorite';
import PersonIcon from '@mui/icons-material/Person';
import SearchIcon from '@mui/icons-material/Search';
import { Link as RouterLink } from 'react-router-dom';
import { useState } from 'react';

const Header = () => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));
  const [drawerOpen, setDrawerOpen] = useState(false);

  const toggleDrawer = (open) => (event) => {
    if (event.type === 'keydown' && (event.key === 'Tab' || event.key === 'Shift')) {
      return;
    }
    setDrawerOpen(open);
  };

  const navItems = [
    { text: 'Home', path: '/' },
    { text: 'Products', path: '/products' },
    { text: 'Categories', path: '/categories' },
    { text: 'Deals', path: '/deals' },
  ];

  const drawerItems = [
    ...navItems,
    { text: 'Cart', path: '/cart', icon: <ShoppingCartIcon /> },
    { text: 'Wishlist', path: '/wishlist', icon: <FavoriteIcon /> },
    { text: 'Account', path: '/login', icon: <PersonIcon /> },
  ];

  return (
    <AppBar position="sticky" elevation={0} sx={{ backgroundColor: 'white', borderBottom: '1px solid #eaeaea' }}>
      <Container maxWidth="xl">
        <Toolbar disableGutters>
          {isMobile && (
            <IconButton
              color="primary"
              aria-label="open drawer"
              edge="start"
              onClick={toggleDrawer(true)}
              sx={{ mr: 2 }}
            >
              <MenuIcon />
            </IconButton>
          )}

          <Typography
            variant="h6"
            noWrap
            component={RouterLink}
            to="/"
            sx={{
              mr: 2,
              display: 'flex',
              fontWeight: 700,
              letterSpacing: '.2rem',
              color: 'primary.main',
              textDecoration: 'none',
            }}
          >
            SHOPHUB
          </Typography>

          <Box sx={{ flexGrow: 1, display: { xs: 'none', md: 'flex' } }}>
            {navItems.map((item) => (
              <Button
                key={item.text}
                component={RouterLink}
                to={item.path}
                sx={{ my: 2, color: 'text.primary', display: 'block', mx: 1 }}
              >
                {item.text}
              </Button>
            ))}
          </Box>

          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <IconButton color="primary" aria-label="search" sx={{ mr: 1 }}>
              <SearchIcon />
            </IconButton>

            {!isMobile && (
              <>
                <IconButton color="primary" aria-label="wishlist" component={RouterLink} to="/wishlist" sx={{ mr: 1 }}>
                  <Badge badgeContent={3} color="secondary">
                    <FavoriteIcon />
                  </Badge>
                </IconButton>

                <IconButton color="primary" aria-label="cart" component={RouterLink} to="/cart" sx={{ mr: 1 }}>
                  <Badge badgeContent={2} color="secondary">
                    <ShoppingCartIcon />
                  </Badge>
                </IconButton>

                <Button
                  variant="contained"
                  color="primary"
                  startIcon={<PersonIcon />}
                  component={RouterLink}
                  to="/login"
                  sx={{ ml: 1 }}
                >
                  Login
                </Button>
              </>
            )}
          </Box>

          <Drawer anchor="left" open={drawerOpen} onClose={toggleDrawer(false)}>
            <Box
              sx={{ width: 250 }}
              role="presentation"
              onClick={toggleDrawer(false)}
              onKeyDown={toggleDrawer(false)}
            >
              <List>
                {drawerItems.map((item) => (
                  <ListItem button key={item.text} component={RouterLink} to={item.path}>
                    {item.icon && <ListItemIcon>{item.icon}</ListItemIcon>}
                    <ListItemText primary={item.text} />
                  </ListItem>
                ))}
              </List>
            </Box>
          </Drawer>
        </Toolbar>
      </Container>
    </AppBar>
  );
};

export default Header;
