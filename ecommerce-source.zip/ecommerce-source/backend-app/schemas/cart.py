from pydantic import BaseModel
from typing import Optional
from datetime import datetime


class CartItemBase(BaseModel):
    product_id: int
    quantity: int = 1


class CartItemCreate(CartItemBase):
    pass


class CartItemUpdate(BaseModel):
    quantity: Optional[int] = None


class CartItem(CartItemBase):
    id: int
    user_id: int
    created_at: datetime
    updated_at: Optional[datetime] = None

    class Config:
        orm_mode = True


class CartItemWithProduct(CartItem):
    product_name: str
    product_price: float
    product_image: Optional[str] = None
