from pydantic import BaseModel
from typing import Optional
from datetime import datetime


class WishlistItemBase(BaseModel):
    product_id: int


class WishlistItemCreate(WishlistItemBase):
    pass


class WishlistItem(WishlistItemBase):
    id: int
    user_id: int
    created_at: datetime

    class Config:
        orm_mode = True


class WishlistItemWithProduct(WishlistItem):
    product_name: str
    product_price: float
    product_image: Optional[str] = None
