from sqlalchemy.orm import Session
from app.models.wishlist_item import WishlistItem
from app.models.product import Product
from app.schemas.wishlist import WishlistItemCreate


def get_wishlist_item(db: Session, wishlist_item_id: int):
    return db.query(WishlistItem).filter(WishlistItem.id == wishlist_item_id).first()


def get_user_wishlist_items(db: Session, user_id: int):
    return db.query(WishlistItem).filter(WishlistItem.user_id == user_id).all()


def get_user_wishlist_item_by_product(db: Session, user_id: int, product_id: int):
    return db.query(WishlistItem).filter(
        WishlistItem.user_id == user_id,
        WishlistItem.product_id == product_id
    ).first()


def create_wishlist_item(db: Session, wishlist_item: WishlistItemCreate, user_id: int):
    # Check if item already exists in wishlist
    existing_item = get_user_wishlist_item_by_product(db, user_id, wishlist_item.product_id)
    if existing_item:
        # Item already in wishlist, return existing
        return existing_item
    
    # Create new wishlist item
    db_wishlist_item = WishlistItem(
        user_id=user_id,
        product_id=wishlist_item.product_id
    )
    db.add(db_wishlist_item)
    db.commit()
    db.refresh(db_wishlist_item)
    return db_wishlist_item


def delete_wishlist_item(db: Session, wishlist_item_id: int):
    db_wishlist_item = get_wishlist_item(db, wishlist_item_id)
    if db_wishlist_item:
        db.delete(db_wishlist_item)
        db.commit()
        return True
    return False


def clear_user_wishlist(db: Session, user_id: int):
    db.query(WishlistItem).filter(WishlistItem.user_id == user_id).delete()
    db.commit()
    return True


def get_wishlist_with_products(db: Session, user_id: int):
    wishlist_items = get_user_wishlist_items(db, user_id)
    result = []
    
    for item in wishlist_items:
        product = db.query(Product).filter(Product.id == item.product_id).first()
        if product:
            result.append({
                **item.__dict__,
                "product_name": product.name,
                "product_price": product.price,
                "product_image": product.image_url
            })
    
    return result
