from sqlalchemy.orm import Session
from app.models.cart_item import CartItem
from app.models.product import Product
from app.schemas.cart import CartItemCreate, CartItemUpdate


def get_cart_item(db: Session, cart_item_id: int):
    return db.query(CartItem).filter(CartItem.id == cart_item_id).first()


def get_user_cart_items(db: Session, user_id: int):
    return db.query(CartItem).filter(CartItem.user_id == user_id).all()


def get_user_cart_item_by_product(db: Session, user_id: int, product_id: int):
    return db.query(CartItem).filter(
        CartItem.user_id == user_id,
        CartItem.product_id == product_id
    ).first()


def create_cart_item(db: Session, cart_item: CartItemCreate, user_id: int):
    # Check if item already exists in cart
    existing_item = get_user_cart_item_by_product(db, user_id, cart_item.product_id)
    if existing_item:
        # Update quantity instead of creating new item
        existing_item.quantity += cart_item.quantity
        db.commit()
        db.refresh(existing_item)
        return existing_item
    
    # Create new cart item
    db_cart_item = CartItem(
        user_id=user_id,
        product_id=cart_item.product_id,
        quantity=cart_item.quantity
    )
    db.add(db_cart_item)
    db.commit()
    db.refresh(db_cart_item)
    return db_cart_item


def update_cart_item(db: Session, cart_item_id: int, cart_item: CartItemUpdate):
    db_cart_item = get_cart_item(db, cart_item_id)
    if db_cart_item:
        update_data = cart_item.dict(exclude_unset=True)
        for key, value in update_data.items():
            setattr(db_cart_item, key, value)
        db.commit()
        db.refresh(db_cart_item)
    return db_cart_item


def delete_cart_item(db: Session, cart_item_id: int):
    db_cart_item = get_cart_item(db, cart_item_id)
    if db_cart_item:
        db.delete(db_cart_item)
        db.commit()
        return True
    return False


def clear_user_cart(db: Session, user_id: int):
    db.query(CartItem).filter(CartItem.user_id == user_id).delete()
    db.commit()
    return True


def get_cart_with_products(db: Session, user_id: int):
    cart_items = get_user_cart_items(db, user_id)
    result = []
    
    for item in cart_items:
        product = db.query(Product).filter(Product.id == item.product_id).first()
        if product:
            result.append({
                **item.__dict__,
                "product_name": product.name,
                "product_price": product.price,
                "product_image": product.image_url
            })
    
    return result
