from sqlalchemy.orm import Session
from sqlalchemy import func
from app.models.product import Product
from app.models.review import Review
from app.schemas.product import ProductCreate, ProductUpdate


def get_product(db: Session, product_id: int):
    return db.query(Product).filter(Product.id == product_id).first()


def get_products(db: Session, skip: int = 0, limit: int = 100, category: str = None, brand: str = None):
    query = db.query(Product)
    
    if category:
        query = query.filter(Product.category == category)
    
    if brand:
        query = query.filter(Product.brand == brand)
    
    return query.offset(skip).limit(limit).all()


def search_products(db: Session, search_term: str, skip: int = 0, limit: int = 100):
    search = f"%{search_term}%"
    return db.query(Product).filter(
        (Product.name.ilike(search)) | 
        (Product.description.ilike(search)) |
        (Product.category.ilike(search)) |
        (Product.brand.ilike(search))
    ).offset(skip).limit(limit).all()


def create_product(db: Session, product: ProductCreate):
    db_product = Product(**product.dict())
    db.add(db_product)
    db.commit()
    db.refresh(db_product)
    return db_product


def update_product(db: Session, product_id: int, product: ProductUpdate):
    db_product = get_product(db, product_id)
    if db_product:
        update_data = product.dict(exclude_unset=True)
        for key, value in update_data.items():
            setattr(db_product, key, value)
        db.commit()
        db.refresh(db_product)
    return db_product


def delete_product(db: Session, product_id: int):
    db_product = get_product(db, product_id)
    if db_product:
        db.delete(db_product)
        db.commit()
        return True
    return False


def get_product_with_reviews(db: Session, product_id: int):
    product = get_product(db, product_id)
    if not product:
        return None
    
    # Get average rating and count of reviews
    review_stats = db.query(
        func.avg(Review.rating).label("average_rating"),
        func.count(Review.id).label("reviews_count")
    ).filter(Review.product_id == product_id).first()
    
    # Get reviews
    reviews = db.query(Review).filter(Review.product_id == product_id).all()
    
    # Add review stats to product
    product_dict = {
        **product.__dict__,
        "average_rating": review_stats.average_rating if review_stats.average_rating else None,
        "reviews_count": review_stats.reviews_count,
        "reviews": reviews
    }
    
    return product_dict
