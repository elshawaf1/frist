from sqlalchemy.orm import Session
from app.models.review import Review
from app.schemas.review import ReviewCreate, ReviewUpdate


def get_review(db: Session, review_id: int):
    return db.query(Review).filter(Review.id == review_id).first()


def get_product_reviews(db: Session, product_id: int, skip: int = 0, limit: int = 100):
    return db.query(Review).filter(Review.product_id == product_id).offset(skip).limit(limit).all()


def get_user_reviews(db: Session, user_id: int, skip: int = 0, limit: int = 100):
    return db.query(Review).filter(Review.user_id == user_id).offset(skip).limit(limit).all()


def create_review(db: Session, review: ReviewCreate, user_id: int):
    db_review = Review(
        user_id=user_id,
        product_id=review.product_id,
        rating=review.rating,
        comment=review.comment
    )
    db.add(db_review)
    db.commit()
    db.refresh(db_review)
    return db_review


def update_review(db: Session, review_id: int, review: ReviewUpdate):
    db_review = get_review(db, review_id)
    if db_review:
        update_data = review.dict(exclude_unset=True)
        for key, value in update_data.items():
            setattr(db_review, key, value)
        db.commit()
        db.refresh(db_review)
    return db_review


def delete_review(db: Session, review_id: int):
    db_review = get_review(db, review_id)
    if db_review:
        db.delete(db_review)
        db.commit()
        return True
    return False
