from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List

from app.db.database import get_db
from app.schemas.order import Order, OrderCreate, OrderUpdate
from app.schemas.user import User
from app.crud import order as order_crud
from app.routes.users import get_current_active_user

router = APIRouter()


@router.get("/", response_model=List[Order])
def read_user_orders(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    orders = order_crud.get_user_orders(db, user_id=current_user.id, skip=skip, limit=limit)
    return orders


@router.get("/{order_id}", response_model=Order)
def read_order(
    order_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    db_order = order_crud.get_order(db, order_id=order_id)
    if db_order is None:
        raise HTTPException(status_code=404, detail="Order not found")
    
    # Check if the order belongs to the current user or if user is admin
    if db_order.user_id != current_user.id and not current_user.is_admin:
        raise HTTPException(status_code=403, detail="Not enough permissions")
    
    return db_order


@router.post("/", response_model=Order)
def create_order(
    order: OrderCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    return order_crud.create_order(db=db, order=order, user_id=current_user.id)


@router.put("/{order_id}", response_model=Order)
def update_order(
    order_id: int,
    order: OrderUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    db_order = order_crud.get_order(db, order_id=order_id)
    if db_order is None:
        raise HTTPException(status_code=404, detail="Order not found")
    
    # Only admin can update order status
    if not current_user.is_admin:
        raise HTTPException(status_code=403, detail="Not enough permissions")
    
    updated_order = order_crud.update_order(db, order_id=order_id, order=order)
    return updated_order


@router.delete("/{order_id}")
def delete_order(
    order_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    db_order = order_crud.get_order(db, order_id=order_id)
    if db_order is None:
        raise HTTPException(status_code=404, detail="Order not found")
    
    # Only admin can delete orders
    if not current_user.is_admin:
        raise HTTPException(status_code=403, detail="Not enough permissions")
    
    success = order_crud.delete_order(db, order_id=order_id)
    return {"detail": "Order deleted successfully"}
