from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List

from app.db.database import get_db
from app.schemas.cart import CartItem, CartItemCreate, CartItemUpdate, CartItemWithProduct
from app.schemas.user import User
from app.crud import cart as cart_crud
from app.routes.users import get_current_active_user

router = APIRouter()


@router.get("/", response_model=List[CartItemWithProduct])
def read_user_cart(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    cart_items = cart_crud.get_cart_with_products(db, user_id=current_user.id)
    return cart_items


@router.post("/", response_model=CartItem)
def add_to_cart(
    cart_item: CartItemCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    return cart_crud.create_cart_item(db=db, cart_item=cart_item, user_id=current_user.id)


@router.put("/{cart_item_id}", response_model=CartItem)
def update_cart_item(
    cart_item_id: int,
    cart_item: CartItemUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    db_cart_item = cart_crud.get_cart_item(db, cart_item_id=cart_item_id)
    if db_cart_item is None:
        raise HTTPException(status_code=404, detail="Cart item not found")
    
    # Check if the cart item belongs to the current user
    if db_cart_item.user_id != current_user.id:
        raise HTTPException(status_code=403, detail="Not enough permissions")
    
    updated_cart_item = cart_crud.update_cart_item(db, cart_item_id=cart_item_id, cart_item=cart_item)
    return updated_cart_item


@router.delete("/{cart_item_id}")
def remove_from_cart(
    cart_item_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    db_cart_item = cart_crud.get_cart_item(db, cart_item_id=cart_item_id)
    if db_cart_item is None:
        raise HTTPException(status_code=404, detail="Cart item not found")
    
    # Check if the cart item belongs to the current user
    if db_cart_item.user_id != current_user.id:
        raise HTTPException(status_code=403, detail="Not enough permissions")
    
    success = cart_crud.delete_cart_item(db, cart_item_id=cart_item_id)
    return {"detail": "Item removed from cart successfully"}


@router.delete("/")
def clear_cart(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    cart_crud.clear_user_cart(db, user_id=current_user.id)
    return {"detail": "Cart cleared successfully"}
