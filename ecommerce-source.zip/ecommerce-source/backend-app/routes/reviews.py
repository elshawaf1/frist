from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List

from app.db.database import get_db
from app.schemas.review import Review, ReviewCreate, ReviewUpdate
from app.schemas.user import User
from app.crud import review as review_crud
from app.routes.users import get_current_active_user

router = APIRouter()


@router.get("/product/{product_id}", response_model=List[Review])
def read_product_reviews(
    product_id: int,
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db)
):
    reviews = review_crud.get_product_reviews(db, product_id=product_id, skip=skip, limit=limit)
    return reviews


@router.get("/user/", response_model=List[Review])
def read_user_reviews(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    reviews = review_crud.get_user_reviews(db, user_id=current_user.id, skip=skip, limit=limit)
    return reviews


@router.post("/", response_model=Review)
def create_review(
    review: ReviewCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    return review_crud.create_review(db=db, review=review, user_id=current_user.id)


@router.put("/{review_id}", response_model=Review)
def update_review(
    review_id: int,
    review: ReviewUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    db_review = review_crud.get_review(db, review_id=review_id)
    if db_review is None:
        raise HTTPException(status_code=404, detail="Review not found")
    
    # Check if the review belongs to the current user
    if db_review.user_id != current_user.id and not current_user.is_admin:
        raise HTTPException(status_code=403, detail="Not enough permissions")
    
    updated_review = review_crud.update_review(db, review_id=review_id, review=review)
    return updated_review


@router.delete("/{review_id}")
def delete_review(
    review_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    db_review = review_crud.get_review(db, review_id=review_id)
    if db_review is None:
        raise HTTPException(status_code=404, detail="Review not found")
    
    # Check if the review belongs to the current user or if user is admin
    if db_review.user_id != current_user.id and not current_user.is_admin:
        raise HTTPException(status_code=403, detail="Not enough permissions")
    
    success = review_crud.delete_review(db, review_id=review_id)
    return {"detail": "Review deleted successfully"}
