from app.routes import users, products, orders, cart, wishlist, reviews

# Import all routes here to make them available for the main app
