from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List

from app.db.database import get_db
from app.schemas.wishlist import WishlistItem, WishlistItemCreate, WishlistItemWithProduct
from app.schemas.user import User
from app.crud import wishlist as wishlist_crud
from app.routes.users import get_current_active_user

router = APIRouter()


@router.get("/", response_model=List[WishlistItemWithProduct])
def read_user_wishlist(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    wishlist_items = wishlist_crud.get_wishlist_with_products(db, user_id=current_user.id)
    return wishlist_items


@router.post("/", response_model=WishlistItem)
def add_to_wishlist(
    wishlist_item: WishlistItemCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    return wishlist_crud.create_wishlist_item(db=db, wishlist_item=wishlist_item, user_id=current_user.id)


@router.delete("/{wishlist_item_id}")
def remove_from_wishlist(
    wishlist_item_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    db_wishlist_item = wishlist_crud.get_wishlist_item(db, wishlist_item_id=wishlist_item_id)
    if db_wishlist_item is None:
        raise HTTPException(status_code=404, detail="Wishlist item not found")
    
    # Check if the wishlist item belongs to the current user
    if db_wishlist_item.user_id != current_user.id:
        raise HTTPException(status_code=403, detail="Not enough permissions")
    
    success = wishlist_crud.delete_wishlist_item(db, wishlist_item_id=wishlist_item_id)
    return {"detail": "Item removed from wishlist successfully"}


@router.delete("/")
def clear_wishlist(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    wishlist_crud.clear_user_wishlist(db, user_id=current_user.id)
    return {"detail": "Wishlist cleared successfully"}
